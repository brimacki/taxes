module unload PrgEnv-pgi
module unload PrgEnv-cray
module unload PrgEnv-intel
module unload PrgEnv-gnu

module unload cray-libsci
module unload cray-petsc
module unload cudatoolkit
module unload craype-accel-nvidia35
module unload cray-libsci_acc

module unload cray-netcdf-hdf5parallel
module unload perftools


module load PrgEnv-pgi
module swap pgi pgi/15.3.0
module load cray-petsc
module load cudatoolkit
# module load netcdf-hdf5parallel
module load cray-netcdf-hdf5parallel
# module load perftools
