#!/bin/bash
export PE_RANK=$ALPS_APP_PE
export PMI_NO_FORK=1
if [ "$PE_RANK" == 0 ];then
echo $1 '--' $2
$1 -- $2
else
$2
fi
